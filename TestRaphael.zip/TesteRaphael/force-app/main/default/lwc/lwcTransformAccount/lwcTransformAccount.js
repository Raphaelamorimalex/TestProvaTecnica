import { LightningElement, api, track } from 'lwc';

export default class LwcTransformAccount extends LightningElement {
   /* @api recordId; // Id do registro que está sendo editado

    @track editedName;
    @track editedAccountNumber;
    @track editedType;

    // Atualiza os valores editados quando os campos padrões são alterados fora do componente
    @api
    set name(value) {
        this.editedName = value;
    }

    @api
    set accountNumber(value) {
        this.editedAccountNumber = value;
    }

    @api
    set type(value) {
        this.editedType = value;
    }

    // Atualiza os campos padrões quando os valores editados são alterados dentro do componente
    handleNameChange(event) {
        this.editedName = event.target.value;
    }

    handleAccountNumberChange(event) {
        this.editedAccountNumber = event.target.value;
    }

    handleTypeChange(event) {
        this.editedType = event.target.value;
    }

    handleSave() {
        // Emita um evento personalizado para notificar o componente pai sobre as alterações
        const customEvent = new CustomEvent('save', {
            detail: {
                editedName: this.editedName,
                editedAccountNumber: this.editedAccountNumber,
                editedType: this.editedType
            }
        });
        this.dispatchEvent(customEvent);
    }*/
}
